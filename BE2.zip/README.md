# BE_HOG

Implementation of the HOG (Histogram of Oriented Gradient) descriptors algorithm for object detection in images as proposed by Navneet Dalal and Bill Trigs.  
